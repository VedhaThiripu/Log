<?php
/**
 * 
 * Application configuration
 *
 * 
 */ 
define("DS", "/");
/**
* 
* Base Directory from web root path 
*
*/

define("BASE_DIR", "/SERVER_LOG_ANALYSIS");
/**
* 
* Base Directory Public
*
*/
define("BASE_DIR_DATA","data");
/**
* 
* Base Directory Vendor
*
*/
define("BASE_DIR_VENDOR", BASE_DIR . DS . "vendors");
/**
* 
* APP 
*
*/
define("BASE_DIR_APP", BASE_DIR . DS . "app");
/**
* 
* APP View
*
*/
define("BASE_DIR_VIEW", BASE_DIR_APP . DS . "View");
/**
* Login
*
*/
define("BASE_DIR_LOGIN", BASE_DIR . DS . "login");
/**
* 
* Host
*
*/

define("DB_HOST","localhost");
/**
* 
* UserName
*
*/
define("DB_USER","root");
/**
* 
* Password
*
*/
define("DB_PASSWORD","");
/**
* 
* Password
*
*/
define("DB_NAME","project");


?>